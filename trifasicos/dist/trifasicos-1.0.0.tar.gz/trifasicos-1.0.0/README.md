# trifasicos
este codigo de python resuelve sistemas trifsicos desbalanceados: estrella_estrella con y sin neutro y resuelve estrella_delta y delta_delta

para utilizarlo se utilizan estas tres lineas de codigo
repositorios.nicolas(numero,voltaje van,angulo,impA,impb,impc)
numero= escoge que tipo de sistema trifasico
1=estrella_estrella con neutro
2=estrella_estrella sin neutro
3=estrella_delta y delta estrella
van=el voltaje de fase parte real
angulo=elangulo que tiene el voltaje
los tres son los valores de las cargas de a b y c respectivamente
